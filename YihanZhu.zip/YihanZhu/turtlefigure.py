from turtle import *
import math

# binary tree
def tree(pen, n, l):
     if n==0 or l<2 :
          return
     #endif
     pen.forward(l)
     pen.left(45)
     tree(pen, n-1, l/2)
     pen.right(90)
     tree(pen, n-1, l/2)
     pen.left(45)
     pen.backward(l)

#end

# quadratic tree
def d(pen, n, l):
     # termination
     if n==0 or l<2:
          return
     #endif
     pen.forward(l)
     pen.left(90)
     d(pen, n-1, l/2)
     pen.right(60)
     d(pen, n-1, l/2)
     pen.right(60)
     d(pen, n-1, l/2)
     pen.right(60)
     d(pen, n-1, l/2)
     pen.left(90)
     pen.backward(l)
#end d

def f(pen, n,l):
     #termination
     if n==0 or l<2:
          return
     #endif
     pen.forward(0.3*l)
     pen.right(45); f(pen, n-1, l/2); pen.left(45)
     pen.forward(0.7*l)
     pen.left(30); f(pen, n-1, l/2); pen.right(30)
     pen.forward(l)
     pen.right(10); f(pen, n-1, 0.8*l); pen.left(10)
     pen.backward(2*l)
#end


def koch(pen, n,l):
     if n==0 or l<2:
          pen.forward(l)
          return
     #endif
     koch(pen, n-1, l/3)
     pen.left(60); koch(pen, n-1, l/3)
     pen.right(120); koch(pen, n-1, l/3)
     pen.left(60); koch(pen, n-1, l/3)

     #end koch

def antiflake(pen, n, l):
     for i in range(3):
          koch(pen,n, l)
          pen.left(120)
          #end for
#end flake

def flake(pen, n, l):
     for i in range(3):
          koch(pen,n, l)
          pen.right(120)
          #end for
#end flake

def gasket3(pen, n, l):
     #termination
     if n==0 or l<2:
          for i in range(3):
               pen.forward(l)
               pen.left(120)
               #end for
          return
     #end if
     gasket3(pen,n-1, l/2); pen.forward(l); pen.left(120)
     gasket3(pen,n-1, l/2); pen.forward(l); pen.left(120)
     gasket3(pen,n-1, l/2); pen.forward(l); pen.left(120)
#end gasket3
     
     
def circle3(pen,n,r):#3 circles repetition
     if n==0 or r<2:
        pen.circle(r)
        return
     pen.circle(r)
     for i in range(3):
          
          circle3(pen, n-1,3**0.5/(2+3**0.5)*r)
          pen.penup()
          pen.left(90)
          pen.forward(r)
          pen.right(60)
          pen.forward(r)
          pen.left(90)
          pen.down()

def circle6(pen,n,r):#6 circles repetition
     if n==0 or r<2:
        pen.circle(r)
        return
     circle6(pen,0,r)
     for i in range(6):
          circle6(pen, n-1,r/3)
          pen.penup()
          pen.left(30)
          pen.forward(r)
          pen.left(30)
          pen.down()


def circle9(pen,n,r):#spotted snow
     if n==0 or r<2:
        pen.circle(r)
        return    
     for i in range(6):
          circle9(pen, n-1,r/3)
          pen.penup()
          pen.right(60)
          pen.forward(1.5*r)
          pen.left(120)
          pen.down()
def circle7(pen,n,r):#overlord flower
     if n==0 or r<2:
        pen.circle(r)
        return
     
     for i in range(6):
          circle7(pen,0,r)
          circle7(pen, n-1,r/3)
          pen.penup()
          pen.right(60)
          pen.forward(r)
          pen.left(120)
          pen.down()

def circle2(pen,n,r):##succeed
     # termination
     pen.speed(0)
     if n==0 or r<2:
          pen.circle(r)
          return
     #endif
     circle2(pen,0,r)
     for i in range(2):
          circle2(pen, n-1,r/2)
          pen.penup()
          pen.left(90)
          pen.forward(2*r)
          pen.left(90)
          pen.pendown()




