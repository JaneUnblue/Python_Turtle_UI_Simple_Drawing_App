# import tkinter
from tkinter import *
from tkinter.ttk import *
import turtlefigure
from turtle import TurtleScreen, RawTurtle
from PIL import Image, ImageTk
from tkinter.font import Font

# Make the window
root = Tk()
root.title("Turtle Generator")
root.geometry("1100x550+300+200")

# Preset font
customFont = Font(slant="roman", family="Times New Roman")

# Make the canvas
canvasFrame = LabelFrame(root, text="Canvas")
canvasFrame.grid(row=0, column=6, columnspan=5, rowspan=5)
canvas = Canvas(canvasFrame, width=650, height=500)
canvas.pack()

# Link TurtleScreen with canvas
screen = TurtleScreen(canvas)
screen.bgcolor("light goldenrod")
w, h = screen.screensize()

# Make a turtle pen connected with the screen
pen = RawTurtle(screen)
pen.color("white")

# Make the control panel
controlFrame = LabelFrame(root, text="Control Panel", width=200, height=200)
controlFrame.grid(row=0, column=0, columnspan=5, rowspan=5, padx=20)

# Create an integer variable to store the Order Value
orderValue = IntVar()

# Create a label and an entry to set the Order Value
orderLabel = Label(controlFrame, text="Order Value:", font=customFont)
orderLabel.grid(row=1, column=0)
orderEntry = Entry(controlFrame, textvariable=orderValue)
orderEntry.grid(row=1, column=1, columnspan=2)

# Set the initial selected value
orderValue.set(3)

# Length value update method
lengthValueLabel = Label(controlFrame, text="Length Value: 0", font=customFont)
lengthValueLabel.grid(row=3, column=0)

lengthScale = Scale(controlFrame, from_=80, to=280, orient=HORIZONTAL)
lengthScale.grid(row=3, column=1, columnspan=2)

# Set the initial value
lengthScale.set(80)

def updateValues(event):
    lengthValue = "{:.1f}".format(lengthScale.get())  # Keep one decimal place
    lengthValueLabel.config(text=f"Length Value: {lengthValue}")

# Bind the callback function to the Scale component
lengthScale.bind("<Motion>", updateValues)

# Create an integer variable to store the pen width value
penWidth = IntVar()

# Create a label and an entry to set the pen width
penWidthLabel = Label(controlFrame, text="Pen Width:", font=customFont)
penWidthLabel.grid(row=4, column=0)

penWidthEntry = Entry(controlFrame, textvariable=penWidth)
penWidthEntry.grid(row=4, column=1, columnspan=2)

# Set the initial value
penWidth.set(3)

# Create an OptionMenu component to choose arrow shape
arrowshapeLabel = Label(controlFrame, text="Arrow Shape:", font=customFont)
arrowshapeLabel.grid(row=0, column=0)

arrowshapeNames = ("classic", "arrow", "turtle", "square", "triangle", "circle")
arrowshape = StringVar()
arrowshapeList = OptionMenu(controlFrame, arrowshape, arrowshapeNames[0], *arrowshapeNames)
arrowshapeList.grid(row=0, column=1, columnspan=3)

# Get the arrow shape
arrowshapeIndex = arrowshapeNames.index(arrowshape.get())

def updateArrowShape(*args):
    selectedshape = arrowshape.get()
    pen.shape(selectedshape)

# Bind the callback function to the OptionMenu to update the pen shape when the selection changes
arrowshape.trace("w", updateArrowShape)

# Create radio buttons to choose canvas color
canvasColorLabel = Label(controlFrame, text="Canvas Color:", font=customFont)
canvasColorLabel.grid(row=7, column=0)
canvasColor = StringVar()
whiteCanvasButton = Radiobutton(controlFrame, text="Gray", variable=canvasColor, value="gainsboro")
blueCanvasButton = Radiobutton(controlFrame, text="Blue", variable=canvasColor, value="blue")
whiteCanvasButton.grid(row=7, column=1)
blueCanvasButton.grid(row=7, column=2)

def updateCanvasColor():
    selectedColor = canvasColor.get()
    if selectedColor == "gainsboro":
        screen.bgcolor("gainsboro")
    elif selectedColor == "blue":
        screen.bgcolor("light sky blue")

# Bind the callback function to the Radiobuttons to update the canvas color
canvasColor.trace("w", lambda *args: updateCanvasColor())

def drawF():
    # Get the values from sliders and widgets
    length = lengthScale.get()
    order = int(orderValue.get())
    penwidth = penWidth.get()

    # Update the canvas color
    updateCanvasColor()

    # Format the length value with one decimal place
    lengthFormatted = "{:.1f}".format(length)

    # Get the selected figure index from the OptionMenu
    figureIndex = figureNames.index(figureStr.get())

    # 清除画布
    canvas.delete("all")

    # 重置Turtle的位置和状态
    pen.reset()
    pen.speed(0)
    pen.width(penwidth)
    pen.color("white")

    # use the figureIndex to call the selected turtle method
    if figureIndex == 0:
        pen.up(); pen.left(90);pen.backward(h/4);pen.down(); pen.right(90);pen.color("seashell4")
        turtlefigure.circle3(pen, order, length)
        
    elif figureIndex == 1:
        pen.up(); pen.left(90);pen.backward(h/4);pen.down(); pen.right(90);pen.color("seashell4")
        turtlefigure.circle6(pen, order, length)


    elif figureIndex == 2:
        pen.up();pen.backward(w/4);pen.down();pen.color("indian red")
        turtlefigure.circle7(pen, order, length)


    elif figureIndex == 3:
        pen.up();pen.backward(w/3-20);pen.down()
        turtlefigure.circle9(pen, order, length)
        
    elif figureIndex == 4:
        pen.up(); pen.left(90);pen.backward(h/2);pen.down();pen.color("green")
        turtlefigure.tree(pen, order, length)

    elif figureIndex == 5:
        pen.up(); pen.left(90);pen.backward(h/2);pen.down();
        turtlefigure.d(pen, order, length)

    elif figureIndex == 6:
        pen.up();pen.backward(w/2);pen.down();pen.color("green")
        turtlefigure.f(pen, order, length)

    elif figureIndex == 7:
        pen.up();pen.backward(w/4);pen.down()
        turtlefigure.koch(pen, order, length)

    elif figureIndex == 8:
        pen.up();pen.backward(w/4);pen.left(90);pen.backward(h/4);pen.right(90); pen.down()
        turtlefigure.antiflake(pen, order, length)

    elif figureIndex == 9:
        pen.up();pen.backward(w/4);pen.left(90);pen.forward(h/4);pen.right(90); pen.down()
        turtlefigure.flake(pen, order, length)

    elif figureIndex == 10:
        pen.up();pen.backward(w/8);pen.left(90),pen.backward(h/4);pen.right(90);pen.down();pen.color("seashell4")
        turtlefigure.gasket3(pen, order, length)
        
    elif figureIndex == 11:
        pen.up();pen.backward(w/8);pen.left(90),pen.backward(h/4);pen.right(90);pen.down();pen.color("seashell4")
        turtlefigure.circle2(pen, order, length)
    # and etc
    
def clearF():
    # Clear the canvas
    canvas.delete("all")

    # Move the turtle to the starting position
    pen.up()
    pen.backward(w/2)
    pen.down()

    # Reset the length slider to its initial value
    lengthScale.set(80)

# Create a hint label
hintLabel = Label(controlFrame, text="", relief="solid", borderwidth=1)
hintLabel.grid(row=9, column=0, columnspan=3)

# Define a function to update the hint label
def updateHintLabel():
    selectedFigure = figureStr.get()

    if selectedFigure == "Triple circle":
        hintLabel.config(text='''Hint:
"      Each large circle is evenly distributed
        with 3 tangent small circles.    "''', font=customFont)
        # Display the image
        img = Image.open("0.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

    elif selectedFigure == "Sextuple circle":
        hintLabel.config(text='''Hint:
"      Each large circle is evenly distributed
        with 6 tangent small circles.    "''', font=customFont)
        # Display the image
        img = Image.open("1.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

    elif selectedFigure == "Overlord flower":
        hintLabel.config(text='''Hint:
"       By adjusting the size and position
          of the repeating circle,
        it looks roughly like an overlord flower.
          Especially use a red color.              "''', font=customFont)
        # Display the image
        img = Image.open("2.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

    elif selectedFigure == "Spotted snowflakes":
        hintLabel.config(text='''Hint:
"       By adjusting the position
          of the repeating circle,
          it looks roughly like a snowflake.
        Especially use white color.
          Blue background is recommended    "''', font=customFont)
        # Display the image
        img = Image.open("3.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

    elif selectedFigure == "Binary Tree":
        hintLabel.config(text='''Hint:
"       By adjusting the position
          of the repeating line,
          it looks roughly like a tree.
        Especially use green color.
          Penwidth of 4 is recommended    "''', font=customFont)
        # Display the image
        img = Image.open("4.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)
        
    elif selectedFigure == "Dandelion":
        hintLabel.config(text='''Hint:
"       By adjusting the position
          of the repeating line,
          it looks roughly like a dandelion.
        Especially use white color.
          Order over 3 is recommended    "''', font=customFont)
        # Display the image
        img = Image.open("5.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)
        
    elif selectedFigure == "Fern":
        hintLabel.config(text='''Hint:
"       By adjusting the position
          of the repeating line,
          it looks roughly like a fern.
        Especially use green color.
          Order over 3 is recommended    "''', font=customFont)
        # Display the image
        img = Image.open("6.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

    elif selectedFigure == "Koch":
        hintLabel.config(text='''Hint:
"       By adjusting the position
        of the repeating line,
        it shows the Koch curve.  "''', font=customFont)
        # Display the image
        img = Image.open("7.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

    elif selectedFigure == "Antiflake":
        hintLabel.config(text='''Hint:
"       By adjusting the position
          of the repeating line, and repeating  
       the Koch curve in the left direction,
          it looks roughly like a triangle. "''', font=customFont)
        # Display the image
        img = Image.open("8.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

    elif selectedFigure == "Flake":
        hintLabel.config(text='''Hint:
"       By adjusting the position
          of the repeating line, and repeating  
        the Koch curve in the right direction,
          it looks roughly like a flake.  "''', font=customFont)
        # Display the image
        img = Image.open("9.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

    elif selectedFigure == "Triangle Sierpinski Gasket":
        hintLabel.config(text='''Hint:
"        By adjusting the position 
          of the repeating line,
        and repeating basic triangles,
          it shows the Triangle Sierpinski Gasket.  "''', font=customFont)
        # Display the image
        img = Image.open("10.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

    elif selectedFigure == "Double circle":
        hintLabel.config(text='''Hint:
"      Each large circle is evenly distributed
        with 2 tangent small circles.    "''', font=customFont)
        # Display the image
        img = Image.open("11.jpg")  
        img = img.resize((250, 150))
        img = ImageTk.PhotoImage(img)
        imageLabel = Label(controlFrame, image=img)
        imageLabel.image = img  # Keep a reference to the image to prevent it from being garbage collected
        imageLabel.grid(row=11, column=0, columnspan=3)

# Create an OptionMenu component to choose the fractal
figureLabel = Label(controlFrame, text="Fractal:", font=customFont)
figureLabel.grid(row=6, column=0)

# Create a dropdown list
figureNames = ("Triple circle","Sextuple circle","Overlord flower",
               "Spotted snowflakes","Binary Tree","Dandelion", "Fern",
               "Koch", "Antiflake", "Flake", "Triangle Sierpinski Gasket",
               "Double circle")
figureStr = StringVar()
figureList = OptionMenu(controlFrame, figureStr, figureNames[0], *figureNames)
figureList.grid(row=6, column=1,columnspan=4)

# Bind a callback function to the OptionMenu to update the hint when the selection changes
figureStr.trace("w", lambda *args: updateHintLabel())

# Initially select "Binary Tree" and display the hint
figureStr.set("Binary Tree")
updateHintLabel()

# Set clear and draw buttons
clearButton = Button(controlFrame, text="Clear", command=clearF)
clearButton.grid(row=8, column=0, columnspan=1)

drawButton = Button(controlFrame, text="Draw", command=drawF)
drawButton.grid(row=8, column=2, columnspan=2)

# Loop it
screen.mainloop()
